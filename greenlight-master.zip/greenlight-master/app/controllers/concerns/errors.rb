# frozen_string_literal: true

module Errors
  class UnsafeHostError < StandardError; end
end
